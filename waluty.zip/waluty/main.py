from typing import List, Any

import requests
import csv
import statistics
import json
import numpy
import matplotlib.pyplot as plt

API_URL = "http://api.nbp.pl/api"
CURRENCY_LIST_URL = f"{API_URL}/exchangerates/tables/A?format=json"
GOLD_LAST_30_URL = f"{API_URL}/cenyzlota/last/30?format=json"
CURRENCY_LAST_30_URL = f"{API_URL}/exchangerates/rates/A/{{}}/last/30?format=json"


def get_currency_list():
    response = requests.get(CURRENCY_LIST_URL)
    if response.status_code == 200:
        data = response.json()
        return data[0]['rates']
    else:
        print("Błąd podczas pobierania listy walut.")
        return []


def get_gold_prices():
    response = requests.get(GOLD_LAST_30_URL)
    if response.status_code == 200:
        return response.json()
    else:
        print("Błąd podczas pobierania cen złota.")
        return []


def get_currency_prices(currency_code):
    response = requests.get(CURRENCY_LAST_30_URL.format(currency_code))
    if response.status_code == 200:
        return response.json()['rates']
    else:
        print(f"Błąd podczas pobierania cen waluty: {currency_code}")
        return []


def save_to_csv(data, filename):
    if not data:
        print(f"Brak danych do zapisania w pliku {filename}.")
        return

    keys = data[0].keys()
    with open(filename, 'w', newline='') as output_file:
        dict_writer = csv.DictWriter(output_file, fieldnames=keys)
        dict_writer.writeheader()
        dict_writer.writerows(data)


def calculate_statistics(prices):
    values = [price['cena'] if 'cena' in price else price['mid'] for price in prices]
    avg = sum(values) / len(values)
    median = statistics.median(values)
    return avg, median


def display_gold_prices():
    prices = get_gold_prices()
    if prices:
        filename = "gold_prices.csv"
        save_to_csv(prices, filename)
        avg, median = calculate_statistics(prices)
        print(f"Średnia cena złota: {avg} PLN, Mediana: {median} PLN")
        print(f"Dane zapisane do pliku {filename}")


def gold_rates():

    response = requests.get("http://api.nbp.pl/api/cenyzlota/last/30?format=json")

    x = []
    y = []

    for gold_rate in response.json():
        # print(f"Dnia {gold_rate['data']} cena złota wynosiła {gold_rate['cena']}")
        x.append(gold_rate["data"])
        y.append(gold_rate["cena"])
    fig, axs = plt.subplots()
    axs.plot(x, y)
    plt.show()


def display_currency_list():
    currency_list = get_currency_list()
    if currency_list:
        print("Aktualne kursy walut:")
        for currency in currency_list:
            print(f"{currency['code']} ({currency['currency']}): {currency['mid']} PLN")


def main():
    print("\nOpcje:")
    print("1: Aktualne ceny walut")
    print("2: Ceny złota z ostatnich 30 dni")
    print("3: Wykres")

    print("Wybierz opcję: ")
    choice = input()
    print(choice)

    if choice == '1':
        display_currency_list()
    elif choice == '2':
        display_gold_prices()
    elif choice == "3":
        gold_rates()

    else:
        print("test " + choice)


if __name__ == "__main__":
    main()
